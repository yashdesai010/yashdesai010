# Budget

An Android application for budget management

<p align="center">
    <img src="https://raw.github.com/7h1b0/Budget/master/framed.png" alt="Budget"/>
</p>