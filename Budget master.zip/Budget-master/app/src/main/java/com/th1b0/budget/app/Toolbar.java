package com.th1b0.budget.app;

import android.support.annotation.Nullable;

/**
 * Created by 7h1b0.
 */

public interface Toolbar {
  void setToolbarTitle(@Nullable CharSequence title);
}
