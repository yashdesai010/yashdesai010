package com.th1b0.budget.model;

/**
 * Created by 7h1b0.
 */

public interface TransactionItem {
  String getTitle();

  int getLayout();
}
